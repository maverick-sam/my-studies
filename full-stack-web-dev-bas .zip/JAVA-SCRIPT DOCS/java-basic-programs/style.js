console.log('sam')
console.log(23)
console.log('sam')
