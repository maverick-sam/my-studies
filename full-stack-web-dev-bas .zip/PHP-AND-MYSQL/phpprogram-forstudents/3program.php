<html>
<head>
<?php
echo "hello sam ";
?>
   </head>
<body>
<?php
echo "hello sam ";
?>
</body>
</html>