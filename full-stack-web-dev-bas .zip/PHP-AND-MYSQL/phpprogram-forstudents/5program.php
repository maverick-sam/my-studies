<?php
$a = 10;
$b = 10;///addition
$c =$a+$b;
echo "addition $a  value   $b is $c <br>";

$d = 10;
$e = 10;///subraction
$f =$d-$e;
echo "subraction $d  value   $e is $f <br>";

$g = 10;
$h = 10;///multiplication
$i =$g*$h;
echo "multiplication $g  value   $h is $i <br>";

$j = 10;
$k = 10;///divisioin
$l =$j/$k;
echo "division $j  value   $k is $l <br>";

?>