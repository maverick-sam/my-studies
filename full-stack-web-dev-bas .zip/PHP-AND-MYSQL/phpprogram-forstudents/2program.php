<!--HTML IS EMBEDDED IN PHP--->
<?php

echo "<h1>  hello sam </h1>"
?>