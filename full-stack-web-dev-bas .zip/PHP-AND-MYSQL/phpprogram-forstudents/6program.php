<?php
$a =10;
$b = 10;
if($a>$b)  // if  ($a<$b)  this condition is false so don't enter the loop
{
    echo "$a is greater than $b is true";
}
?>











