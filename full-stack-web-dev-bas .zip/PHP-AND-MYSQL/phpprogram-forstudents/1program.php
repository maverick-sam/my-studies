<?php
echo "hello sam <br>";
print "hello sam ";


?>