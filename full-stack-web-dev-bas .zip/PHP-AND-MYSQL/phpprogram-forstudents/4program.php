<?php
$name = "sam"; 
$num =12;
$float =33.3;

echo "$name<br>";
echo "$num<br>";
echo "$float<br>";

?>
