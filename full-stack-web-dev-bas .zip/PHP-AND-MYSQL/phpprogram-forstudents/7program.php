<?php
$a =10;
$b = 9;
if($a>$b)  // if  ($a<$b)  this condition is false  enter else statement
{
    echo "$a is greater than $b is true";
}
else
{
    echo "$a is lessar then $b that condition is false";
}
?>
