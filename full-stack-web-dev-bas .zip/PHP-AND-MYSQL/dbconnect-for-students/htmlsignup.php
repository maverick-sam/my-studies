<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php login</title>
</head>
<body style="background-color:brown" >
    <center>
<form method="POST" action="dbsignup1.php">
<label><h1>USER NAME:</h1></label>
<input type="text" name="username" placeholder="username">
<label><h1>PASSWORD:</h1></label>
<input type="password" name="password" placeholder="password"></br>
<button type="submit">click here</button>
</form>
    </center>



</form>    
</body>
</html>