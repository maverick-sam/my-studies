<?php

if(!isset($_POST['submit']))
{
$username =$_POST['username'];
$password = $_POST['password'];
$con = mysqli_connect("localhost","root","","ciri");
$sql = "INSERT INTO witch2(username, password) values('$username','$password')";
$result =mysqli_query($con,$sql);

if($result)
{
    echo " successfully sign up";
}
else{
    echo "database not successfully connected";
}
}
?>