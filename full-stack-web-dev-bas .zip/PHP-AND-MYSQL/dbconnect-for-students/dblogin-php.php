<?php

// Check if the form was submitted
if(isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Connect to MySQL database
    $con = mysqli_connect("localhost", "root", "", "ciri");
    
    // Check connection
    if (mysqli_connect_errno()) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT * FROM witch WHERE username=? AND password=?";
    $stmt = mysqli_stmt_init($con);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        die("SQL statement preparation failed");
    } else {
        // Bind parameters to the statement
        mysqli_stmt_bind_param($stmt, "ss", $username, $password);
        
        // Execute the statement
        mysqli_stmt_execute($stmt);
        
        // Get result
        $result = mysqli_stmt_get_result($stmt);
        
        // Check if there's a match
        if (mysqli_num_rows($result) > 0) {
            // Redirect to profile.php upon successful login
            header("Location:html-login.php");
            exit(); // Make sure to exit after redirection
        } else {
            echo "Invalid username or password"; // Display error message
        }
    }

    // Close statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($con);

} else {
    // If the form was not submitted, show an error
    echo "Form submission error";
}

?>
