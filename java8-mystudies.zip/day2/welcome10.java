import java.util.*;

class Test{
	public static void main(String args[])
	{
		ArrayList<String> al = new ArrayList();
		al.add("SAM");
		al.add("JOHN");
		al.add("WICK");
		al.add("MAV");
		al.add("RICK");
		System.out.println(al);
		
		Iterator itr =al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("/n under for each");
		al.forEach((fe)->{
			
		System.out.println(fe);	
		}
			);
	}
}