import java.util.*;
class Welcome{
	public static void main(String args[])
	{
		String[] str = new String[10];
		
		
	Optional<String>opt=Optional.ofNullable(str[5]);
        boolean	 boo =opt.isPresent();
		System.out.println(boo);
	}
}	