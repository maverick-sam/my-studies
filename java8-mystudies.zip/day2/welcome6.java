interface Test{
	void hello();
}
class Welcome{
	Welcome(){
		System.out.println("this is go method");
		System.out.println("this is techys asylum");
	}
	public static void main(String args[])
	{
		Test t1=Welcome::new;
		t1.hello();
	Welcome obj = new Welcome();
	}
}