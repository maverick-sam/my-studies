import java.util.*;

class Test{
public static void main(String args[])
{
String[] str = new String[10];
str[5]="the value isn here";
Optional<String>opt =Optional.ofNullable(str[5]);
boolean boo =opt.isPresent();
if(boo)
{
System.out.println("the value is present");
String values =opt.get();
System.out.println("the string value is"+values);
}
else{
	System.out.println("the values is not present");
}
}
}




	