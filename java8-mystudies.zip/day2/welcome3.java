class Test implements Runnable{
	public void run(){
		System.out.println("test thread is running");
	}
}
class Welcome{
	public static void main (String args[])
	{
		Runnable r1=()->{
			System.out.println("test thread is running");
		};
		Thread t2 = new Thread(r1);
		t2.start();
	}