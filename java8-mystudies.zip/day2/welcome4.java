class Welcome{
public static void go(){
System.out.println("test thread is running");
}
public static void main(String args[])
{
	
	Thread r2 = new Thread(Welcome::go);
	r2.start();
	
}
}
	