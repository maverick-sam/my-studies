@FunctionalInterface
interface Test{
void go();
}
class Welcome{
public void go1(){
System.out.println("hello sam")	;
System.out.println("techys asylum");
}
public static void main(String args[])
{
	Welcome wel = new Welcome();
	Test t1=wel::go1;
	t1.go();
	wel.go1();
}
}