@FunctionalInterface
interface Test{
void hello();
}
class Welcome{
public static void go(){
System.out.println("this is go method");
}
public static void main(String args[])
{
	Test t1=Welcome::go;
	
	t1.hello();
	
}}
	 