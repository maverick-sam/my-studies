class Welcome{
	public static void main(String args[])
	{
		String[] str = new String[10];
		String val = str[5].toLowerCase();
		System.out.println(val);
	}
}