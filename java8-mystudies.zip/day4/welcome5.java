import java.util.function.*;
class Test{
public static void main(String args[]){
System.out.println("this is main method");
Predicate<Integer> pre =(age)-> age>18;
boolean value = pre.test(20);
System.out.println(value);
}}
