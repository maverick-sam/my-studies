import  java.util.function.Consumer;
class Test
{
	
	public static void main(String args[])
	{
		System.out.println("this is main method");
		
		Consumer<String> con=new Consumer<>(){
			public void accept(String name)
			{
			System.out.println("the name is"+name);
			}};
		con.accept("sam");
		
		
		
	}
	
}