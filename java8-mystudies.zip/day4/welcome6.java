without lamda expression

import java.util.function.Consumer;
class Test implements Consumer<String>
{
public void accept(String name){

System.out.println("your name is john"+name);
}
public static void main(String args[]){
System.out.println("this is main method");
Test obj=new Test();
obj.accept("maverick");
}
}
	