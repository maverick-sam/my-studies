import java.util.function.Consumer;

class Test{
	public static void main(String args[])
	{
		System.out.println("the consumer is an functional interface");
		Consumer<String> accept =(String name)->{
			System.out.println("the name is "+name);
		};
		accept.accept("sam");
	}
}
	