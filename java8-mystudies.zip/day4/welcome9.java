import java.util.function.*;
class Test{
	public static doub
    public static void main(String args[]){
        System.out.println("this is main method");
        Supplier<String> sup=
        
        String name=sup.get();
        System.out.println("this is my name"+name);
        
    }
    
}