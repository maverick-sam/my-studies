import java.util.function.*;
class Test{
	public static void main(String args[]){
		System.out.println("this is main method");
		Predicate<Integer> pre =(age) ->{
			boolean value = false;
			if(age>18){
				System.out.println("you're eligiple for vote");
			value=true;
			}
		return value;};
		boolean value2=pre.test(19);
		System.out.println(value2);
	}
}
			