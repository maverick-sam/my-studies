import java.util.function.*;
class Test {
    public  static boolean value(int age){
   
    if(age>18)
    return true;
    return false;
       
    }
    
    
            public static void main(String args[]) {
                System.out.println("this is main method");    
                Predicate<Integer> pre=Test::value;
                   
              
                boolean value2=pre.test(90);
                System.out.println("value is "+value2);
                
            }    
}