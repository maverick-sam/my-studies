import java.util.function.*;

class Test{
            public static String name(String name2){
             String value="your name is "+name2;
                return value;
            }
    public static void main (String args[]){
        System.out.println("this is main method");
        Function<String,String> fun=Test::name;
        
      
        String value2=fun.apply("john");
        System.out.println(value2);
        String value3=name("wick");
        System.out.println(value3);
        
    }

    
}






