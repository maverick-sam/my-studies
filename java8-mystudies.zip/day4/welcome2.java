import java.util.function.*;
class Test{
public  void print(String name)
{
	System.out.println("the print name is "+name);
}
public static void main(String args[]){
System.out.println("this is main method");
Test obj = new Test ();
	Consumer<String> con=obj::print;
	con.accept("sam");
	obj.print("john");
}
}