import java.util.function.*;

class Test {
    public static void main(String args[]) {
        System.out.println("sam");
        Consumer<String> con = (String name) -> {
            System.out.println("your name is " + name);
        };
        con.accept("john");
    }
}
