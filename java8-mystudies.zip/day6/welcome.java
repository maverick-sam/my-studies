import java.util.*;
import java.util.stream.*;
class Test {
    public static void main (String args[]) { 
        String str="hello world";
        
        Map<Character,Long>  map=str.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(c->c , Collectors.counting()));
            
            
       // Map<Character,Long> map = str.chars().mapToObj(c -> (char)c).collect(Collectors.groupingBy(c -> c, Collectors.counting()));
			
            
            
            
            
            System.out.println(map);
    
    
}}