import java.util.*;
class Welcome{
public static void main(String args[])
{//encrypt the message
String str = new String("hi i am sam");
System.out.println(str);
Base64.Encoder encoder =Base64.getEncoder();
byte[] bystr =str.getBytes();
System.out.println(bystr);
byte[] bystr2 =encoder.encode(bystr); 
System.out.println(bystr2);
//decrypt the message
Base64.Decoder decoder =Base64.getDecoder();
byte[] by = decoder.decode(bystr2);
System.out.println(by);
String ans = new String(by);
System.out.println(ans); 


}
}	