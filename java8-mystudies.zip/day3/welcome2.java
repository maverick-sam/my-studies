import java.util.*;
class B{
public static void main(String args[])
{
String url =  new String("https://www.techyasylum.com")	;
Base64.Encoder encoder = Base64.getUrlEncoder();
String str=encoder.encodeToString(url.getBytes());
System.out.println(str);
Base64.Decoder decoder =Base64.getUrlDecoder();
//   byte[] by=decoder.decode(str);
//    System.out.println(by);
String strr = new String(decoder.decode(str));
System.out.println(strr);


}
}