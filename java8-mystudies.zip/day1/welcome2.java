
interface Test{
	void go();
   default void go1(){
   System.out.println("this is go1");}
static void go2(){
	System.out.println("this is go2");
}}
class Welcome{


	public static void main(String args[]){
	
Test t1=()->System.out.println("this is go");
	
		System.out.println("main method");
		
		t1.go();
		t1.go1();
		Test.go2();
	}
}