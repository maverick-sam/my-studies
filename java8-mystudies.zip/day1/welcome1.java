interface Test{
	void  go();
	default void go1(){
		System.out.println("goi");
}}
class B {
	public static void main(String args[])
	{
		System.out.println("this is main");
				
				Test t1 =()->System.out.println("go1");

		
		
	t1.go();
   t1.go1();
		}
    }
