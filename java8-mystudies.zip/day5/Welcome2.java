import java.util.*;
import java.util.*;
import java.util.stream.*;
class Test{
    int id;
    String name;
    float price;
    public Test(int id,String name,float price) {
        this.id=id;
        this.name=name;
        this.price=price;
        
    }
     public String toString(){
         return  id+":"+name+":"+price+":";
     }   
    
}
public class Welcome {
    public static void main(String args[]) {
        List<Test> product=new ArrayList<Test>();
        product.add(new Test(1,"windows",30000f));
        product.add(new Test(2,"mac",28000f));
        product.add(new Test(3,"linux",28000f));
        product.add(new Test(4,"ubundu",28000f));
        product.add(new Test(5,"hat",28000f));

               Stream stream=product.stream();
               Stream stream2 =stream.filter((p)->((Test)p).price<30000f);
               Stream stream3=stream2.map(p->p);
      List<Test> prodcuctsort=(List)stream3.collect(Collectors.toList());           
    
        System.out.println(prodcuctsort);
    }
}
