import java.util.*;
import java.util.*;
import java.util.stream.*;
class Test{
int id;
String name;
float value;
public Test(int id, String name,float value)
{
this.id=id;
this.name=name;
this.value=value;
}
public String toString(){

return id+":"+name+":"+value+":"; 
}
}
public class Welcome1{
	public static void main(String args[]){
		List<Test> product = new ArrayList<Test>();
		product.add(new Test(1,"windows",30000f));
		product.add(new Test(2,"mac",28000f));
		product.add(new Test(3,"linux",28000f));
		product.add(new Test(4,"parat",28000f));
		product.add(new Test(5,"hat",1111f));
	
Set  count=product.stream().filter(p->p.value<30000f).map(p->p.value).collect(Collectors.toSet());







    System.out.println(count);	
	}
}














