import java.util.*;
class Test{
	int id;
	String name;
	float amount;
	public Test(int id, String name,float amount) {
		this.id=id;
		this.name=name;
		this.amount=amount;
	}
	public String toString() {
		return id+":"+name+":"+amount+":";
	}
}

public class Welcome{
	public static void main(String args[]) {
		ArrayList<Test> prodectlist = new ArrayList<Test>();
		prodectlist.add(new Test(1,"lenove",50000f));
		prodectlist.add(new Test(2,"apple",28000f));
		prodectlist.add(new Test(3,"samsung",28000f));
		prodectlist.add(new Test(4,"windowa",28000f));
		prodectlist.add(new Test(5,"linux",30000f));
		
		ArrayList<Test> prodectsortlist = new ArrayList<Test>();
		for(Test product:prodectlist) {
			if(product.amount<30000){
				prodectsortlist.add(product);
			}
		}
		System.out.println(prodectsortlist);
	}
