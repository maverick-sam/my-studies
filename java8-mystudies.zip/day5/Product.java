import java.util.*;
class Test{
	int id;
	String name;
	float amount;
	public Test(int id, String name,float amount) {
		this.id=id;
		this.name=name;
		this.amount=amount;
	}
	public String toString() {
		return id+":"+name+":"+amount+":";
	}
}

public class Product{
	public static void main(String args[]) {
		ArrayList<Product> prodectlist = new ArrayList<Product>();
		prodectlist.add(new Product(1,"lenove",50000f));
		prodectlist.add(new Product(2,"apple",28000f));
		prodectlist.add(new Product(3,"samsung",28000f));
		prodectlist.add(new Product(4,"windowa",28000f));
		prodectlist.add(new Product(5,"linux",30000f));
		
		ArrayList<Product> prodectsortlist = new ArrayList<>(Product);
		for(Prodect product:prodectlist) {
			if(product.amount<30000){
				prodectsortlist.add(product);
			}
		}
		System.out.println(prodectsortlist);
	}
}