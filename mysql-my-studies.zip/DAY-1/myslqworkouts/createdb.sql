use db;
select * from employee;
select id, first_name ,date_format(hire_date  "%M %D,%Y") as formatedhiredate from employee;
