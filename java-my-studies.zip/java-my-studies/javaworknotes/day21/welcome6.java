import java.util.*;
class B{
	public static void main(String args[])
	{
		Stack  s = new Stack();
		s.add(1);
		s.add('s');
		s.add("sam");
System.out.println(s);

Iterator itr = s.iterator();
  while(itr.hasNext());
  {
	  
  System.out.println(itr.next());
  }
  
	}
}
 