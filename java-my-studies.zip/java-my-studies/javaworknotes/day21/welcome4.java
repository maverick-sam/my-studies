import java.util.*;
class B{
	public static void main(String args[])
	{
		LinkedList ll = new LinkedList();
		ll.add("sam");
		ll.add(123);
		ll.add('d');
		System.out.println(ll);
		Object s =ll.poll();
		System.out.println(s);
			System.out.println(ll);
			
	}
}
