import java.util.*;
class B{
	public static void main(String args[])
	{
		LinkedList ll = new LinkedList();
		ll.add(123);
		ll.add("sam");
		ll.add('m');
		LinkedList l2 = new LinkedList();
		l2.add(12);
		l2.add("sm");
		l2.add('j');
		System.out.println(ll);
		System.out.println(l2);
		ll.addAll(l2);////l2 is implemented class name
		Iterator itr = ll.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}
		