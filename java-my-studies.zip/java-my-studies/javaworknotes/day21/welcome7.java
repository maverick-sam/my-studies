import java.util.*;
class B{
	public static void main(String args[])
	{
		Stack  s = new Stack();
		s.add(1);
		s.add('s');
		s.add("sam");
System.out.println(s);
int val =s.search("sam");
System.out.println(val);

}}
    