import java.util.*;
class B{
	public static void main(String args[])
	{
		Vector v =new Vector();
		v.add('a');
		v.add("sam");
	
		System.out.println(v);
		
		int values = v.capacity();
		System.out.println(values);
		Iterator itr = v.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		
		}
	}
}
