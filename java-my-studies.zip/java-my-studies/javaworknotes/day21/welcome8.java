import java.util.*;
class B{
	public static void main(String args[])
	{
		LinkedList<String> ll=new LinkedList<String> ();
ll.add("sam");
ll.add("john");
ll.add("vick");
ll.add("vikram");
System.out.println(ll);
for(String all :ll){
	
System.out.println(all);
	}
}
}

		