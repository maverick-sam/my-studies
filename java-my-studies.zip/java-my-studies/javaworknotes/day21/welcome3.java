import java.util.*;
class B{
	public static void main(String args[])
	{
		LinkedList ll = new LinkedList();
		
		System.out.println(ll);
Object s =ll.peekFirst();
System.out.println(s);
System.out.println(ll);
	}
}
