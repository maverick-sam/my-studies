import java.util.*;
class Welcome{
	public static void main(String args[])
	{
		LinkedList ll=new LinkedList();
		ll.add('s');
		ll.add(123);
		ll.add(123);/// it's hallows duplicate values
		ll.add("john");
		System.out.println(ll);
Iterator itr = ll.iterator();
while(itr.hasNext())
{
System.out.println(itr.next());
	
	
	
	
	
	}
}
}