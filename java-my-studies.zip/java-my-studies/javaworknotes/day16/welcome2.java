class B{
	public static void main(String args[])
	{
		float value = Math.abs(-12.45f);
		System.out.println(value);
	}
}