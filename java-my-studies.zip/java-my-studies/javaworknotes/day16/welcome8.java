class B
{
	public static void main(String args[])
	{
		int val = 200;
		Integer val1 = val;
		byte val2 = val1.byteValue();
		System.out.println(val2);
		
		
	
	}
}	