class B 
{
	public static void main(String args[])
	{
		double value = Math.abs(-12.4578);
		System.out.println(value);
	}
}