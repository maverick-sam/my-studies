class B{
	public static void main(String args[])
	{
		System.out.println(Boolean.FALSE);
		System.out.println(Boolean.FALSE);
		System.out.println(Boolean.TYPE);
	
	
Boolean married = new Boolean(true);
boolean val2 = married.booleanValue();


	
	System.out.println(val2);
	
	
	
	
	}
} 