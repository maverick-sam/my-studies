class B{
	public static void main(String args[])
	{
char gender='a';
Character values = new Character(gender);
System.out.println(values);
	System.out.println(Character.SIZE);
	char val2=values.charValue();
	System.out.println(val2);
	}
	
}
	