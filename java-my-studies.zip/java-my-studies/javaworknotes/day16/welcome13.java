class B
{
	  public static void main(String args[])
{
	/*	boolean marriedmen =true;
		boolean marriedwomen=true;
		boolean result=marriedmen.equals(marriedwomen);
		System.out.println(result);



Boolean marriedmen=new Boolean(true);
Boolean marriedwomen=new Boolean(false);
boolean result=marriedmen.equals(marriedwomen);
System.out.println(result);

*/

String smarried=new String("true");
Boolean values=Boolean.getBoolean(smarried);
System.out.println(values);
}
}   