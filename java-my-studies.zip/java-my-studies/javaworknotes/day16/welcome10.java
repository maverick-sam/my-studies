class B{
	public static void main(String args[])
	{
/*	String height=new String("157.46");
Double obj = new  Double(height);
	System.out.println(obj);


double height =234.45;
Double height2 = Double.MIN_VALUE;
System.out.println(height2);

*/


Double value = new Double(234.34);
int value2 = value.intValue();


System.out.println(value2);
	}
}  