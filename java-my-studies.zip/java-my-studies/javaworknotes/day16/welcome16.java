////////////// string boolean

class B {
	
		public static void main(String args[])
		{
String values = new String("true");
String val=values.toString();
System.out.println(val);
		}
	}

			