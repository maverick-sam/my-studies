class B {
	public static void main(String args[])
	{
	

String obj = Integer.toString(87);
System.out.println(obj);

System.out.println(obj.charAt(1));



	}
}