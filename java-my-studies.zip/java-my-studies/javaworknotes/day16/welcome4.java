class B 
{
	public static void main(String args[])
	{
		float value = Math.min(237.39f,344.43f);
		System.out.println(value);
		System.out.println(Math.random());
double val = Math.sqrt(4);
		System.out.println(val);
	}
}