class B
{
public static void main (String args[])
{
	int value = Math.addExact(12,40);
	System.out.println(value);
}
}