class B
{
	public static void main(String args[])
	{
		String married = new String("false");
	Boolean values2 = new Boolean(married);
		System.out.println(values2);
	
	boolean val = true;
	System.out.println(val);
	Boolean val2 = new Boolean(val);
	System.out.println(val2.TYPE);
	
	
	
	
	}
}