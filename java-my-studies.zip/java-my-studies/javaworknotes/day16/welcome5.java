class B{
	public static void main(String args[])
	{
		double  value =  Math.pow(2,4);
		System.out.println(value);
	}
}