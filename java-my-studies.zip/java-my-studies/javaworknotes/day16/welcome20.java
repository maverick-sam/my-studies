class B {
	public static void main(String args[])
	{
		boolean values=Character.isUpperCase('a');
		System.out.println(values);
	}
}