class B
{
	public static void main(String args[])
	{
		String values =Double.toString(12.34);
		System.out.println(values);
	}
}