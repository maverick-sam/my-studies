class C
{
	public static void main(String args[])
	{
	long val=System.currentTimeMillis();
		System.out.println(val);
		
		
	}
}