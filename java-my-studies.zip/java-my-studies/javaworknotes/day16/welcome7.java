class B
{
	public static void main(String args[])
	{
		int val = 200;
		Integer val3 = val;
		String val1=val3.toString();
		System.out.println(val1);
		
		
	}
}