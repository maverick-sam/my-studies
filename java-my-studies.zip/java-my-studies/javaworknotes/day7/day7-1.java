 class A{
public void a(){
System.out.println("this is A class a method");/////////// non static
}
public static void a1(){          ////////////////// static
System.out.println("this is a1 method in a class");
 }}
class Test{
public static void main(String args[])/////////////////static
{
	
System.out.println("this is main method");
Test abc=new Test();
	abc.main1();
}
public void main1()////////////////non static
{
	
System.out.println("this is main1 method");
A xyz =new A();
	xyz.a();
	A.a1();
}
}	 