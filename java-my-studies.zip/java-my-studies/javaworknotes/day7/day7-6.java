class Test{
	public static void main(String args[])
	{
		for(int i=1;i<=5;i++)
		{
			for(int j=5;j>=1;j--)
			{
				if(i<=j){
				System.out.print(j+" ");
			}
			}
			System.out.println();
		}
	}
}

/*
54321
5432
432
32
1
*/