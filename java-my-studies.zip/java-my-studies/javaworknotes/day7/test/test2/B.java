package test.test2;

public class B{
	public  void m1(){
		
	System.out.println("this is m1 method");
	}
	
		public static void m2(){
			System.out.println("this is m2 method");
		B obj2=new B();
		obj2.m1();
		}
	}

			