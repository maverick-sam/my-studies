package test.test1;
import test.test2.B;

public class A{
	public static void main(String args[])
	{
		System.out.println("this is main");
		go();
A obj=new A();
	obj.good();	
	}
	public static void go(){
		System.out.println("this is go method");
	
	}
	public void good(){
		System.out.println("this is good method");
		B obj1=new B();
		obj1.m1();
		B.m2();
}}