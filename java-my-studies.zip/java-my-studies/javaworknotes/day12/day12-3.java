interface Bank{
	public void deposit();
}
class  Indian implements Bank{
	public void deposit(){
		System.out.println("indian bank deposit");
}}
	class Sbi implements Bank{
		public void deposit()
		{
			System.out.println("this is Sbi bank deposit");
		}
	}
	class Customer {
		public static void main(  String args[] )
		{
			Bank obj =new Indian();
			obj.deposit();
			Bank obj1=new Sbi();
			obj1.deposit();
		  
		}
	}