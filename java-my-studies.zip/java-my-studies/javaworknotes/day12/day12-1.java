class A{
	public void  go(){
		System.out.println("this is go method");
}}
	class B extends A {
		public void good(){
			System.out.println("this is good");
		}
		public void m1()
		{
			System.out.println("this is m1 method");
		}
		public static void main(String args[])
		{
			B obj = new B();////////////////////////////// normal object creation
			obj.go();
			obj.good();
			obj.m1();
		}
	}