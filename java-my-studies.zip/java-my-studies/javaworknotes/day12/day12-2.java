interface A {
	void  go();
  void  good();
}
	abstract class B implements A {
		public void go(){
			System.out.println("this is go b extend method");/////////////////  overrided method was  print
		}
	}
	class C extends B implements A
	{
		public void good(){
			System.out.println("good method");
		}
	
	
		
		
			public static void main(String args[])
			{
				C obj = new C();//
				obj.go();
				obj.good();
			}
		
			
	}