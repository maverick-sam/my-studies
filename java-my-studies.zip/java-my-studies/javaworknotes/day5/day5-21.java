class Go{
public void good(){
	System.out.println("this is good ");
}
}
class Good{
public  void good()	{
System.out.println("this is go");
Go xyz = new Go();
xyz.good();
}
public static void main (String args[])
{
System.out.println("this is main");
Good abc = new Good();
abc.good();



}
}  