class Test{
	public static void main(String args[])
	{

		for(int i=0;i<=2;i++)
		{
			for(int j=1;j<=3;j++){
				System.out.print(j+"");
			}
			System.out.println();
		}
	}
}
