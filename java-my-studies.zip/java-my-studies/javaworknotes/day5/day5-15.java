class Test{
public static void main (String args[])
{
int a[][]={{10,20,30},{40,50,60},{12,34,34}}; ///this length is count set value 2
for(int i=0;i<a.length;i++)
{
	for(int j=0;j<a[i].length;j++) /// this length i count first set count value
	{
		System.out.print(a[i][j]+" ");
	}
	System.out.println();
}
}
}
