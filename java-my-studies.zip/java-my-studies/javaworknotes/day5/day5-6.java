class Test{
public static void main (String args[])
{
	int value =1;
	int i=1;
	int j=1;
	while(i<=3){//////////outer loop
	j=1; ////// innerloop initialization 
	while(j<=3)
	{
		System.out.print(value+" ");/////////inner logics
		j++;////////////////////increment for inner loop
		value++; //////////incremernt for var value
	}
	System.out.println();/////outer loop logics
	i++;//////////////outerloop increment
	}
}
}
