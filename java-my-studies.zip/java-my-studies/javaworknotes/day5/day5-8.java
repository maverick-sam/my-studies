 class Test{
public static void main (String args[])
{
	int table=1;
	int i=1;
	{
		while(table<=20)
		{
			 i=1;
			while(i<=10)
			{
				System.out.println(i+"*"+table+"-"+table*i);
				i++;
			}
			System.out.println("-----------------------------");
		table++;
		}
	}
}
 }