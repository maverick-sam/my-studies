class Go{
public static void main (String args[])
{
System.out.println("this is main");
Go xyz = new Go();
xyz.good();
}
public  void good(){
System.out.println("this is good");
go();
}
public  void go(){
System.out.println("this is go");
}
}