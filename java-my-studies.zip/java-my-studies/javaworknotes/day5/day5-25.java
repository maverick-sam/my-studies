class Test{   //explicitly  is store large values in small data types
public static void main(String args[])
{
	int x=12;
	byte	z=(byte)x;

System.out.println(z);


}}