class Test{
public static void main (String args[])
{
int array[] = new int[]{1,20,21,40,33};
for(int i=0;i<array.length;i++)/////array.length is count of value  i=0 is ///length is use d to calculate array value size
if(array[i]%2==0)
{
System.out.println(array[i]);

}

}
} 
