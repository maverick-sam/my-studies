class Test{
public static void main (String args[])
{
	int value =1;
do
{
	System.out.println("Shankar");
value++;
}
while(value<=10);

	
	
	

}
}
