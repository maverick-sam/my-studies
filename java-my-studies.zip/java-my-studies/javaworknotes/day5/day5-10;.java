class Test{
public static void main (String args[])
{
int a[] = new int[]{10,20,30,40,50};
for(int i=0;i<=4;i++){
System.out.println(a[i]);

}
}
}