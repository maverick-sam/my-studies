class Test{   //explicitly  is store large values in small data types
public static void main(String args[])
{
byte x=121234567890;  ///////////// is an error integer number to large
short y=x;
int z=y;
long z1=z;
float z2=z1;
double z3=z2;

System.out.println(x);
System.out.println(y);
System.out.println(z);
System.out.println(z1);
System.out.println(z2);
System.out.println(z3);
}
}