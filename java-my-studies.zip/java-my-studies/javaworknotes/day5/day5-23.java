class Test{   ////// implicite store small values in store large data type
public static void main(String args[])
{
byte x=12;
short y=x;
int z=y;
long z1=z;
float z2=z1;
double z3=z2;

System.out.println(x);
System.out.println(y);
System.out.println(z);
System.out.println(z1);
System.out.println(z2);
System.out.println(z3);
}
}