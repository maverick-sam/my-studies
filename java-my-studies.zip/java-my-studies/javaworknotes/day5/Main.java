 class Good{
public static void class1(){
System.out.println("this is class 1 method");
 }}
 class Main{
	public static void main(String args[]){
System.out.println("this is main method");	
main1();
Good.class1();
}
public static void main1(){
System.out.println("this is main 1 method");
}
}