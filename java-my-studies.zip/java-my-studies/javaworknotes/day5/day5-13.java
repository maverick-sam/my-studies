class Test{
public static void main (String args[])
{
char array[] = new char[]{'o','a','w','i','u'};
for(int i=0;i<array.length;i++)/////array.length is count of value  i=0 is ///length is use d to calculate array value size
if(array[i]=='z' ||array[i]=='z' ||array[i]=='z' ||array[i]=='z' ||array[i]!='z' )// == that symbol is equal  != that symbol is not equal
/// || that symbol is or anyone in true that is true
{
System.out.println(array[i]);

}}
} 
