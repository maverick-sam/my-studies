class B extends Thread{
public void run(){
try{
for(int i=0;i<5;i++)
{
Thread.sleep(1000);
System.out.println(i);
}}
catch(Exception e)
{
System.out.println("error");
}}
public static void main (String args[])
{
	B obj = new B();
	obj.start();
	B obj1 = new B();
	obj1.start();
	B obj2 = new B();
	obj2.start();
}
}