class B extends Thread{
	public void run(){
		for(int i=0;i<6;i++)
		{
			Thread t =Thread.currentThread();
			String tname =t.getName();
			System.out.println(tname+":"+i);
		}
	}
	public static void main(String args[])
	{
		try{
		
		System.out.println("program started");
		B obj = new B();
		obj.setName("SAM");
		obj.start();
		obj.join();
		
		B obj2 = new B();
		obj2.setName("MAVRICK");
		obj2.start();
		obj2.join();
		
		B obj3 = new B();
		obj3.setName("JOHN");
		obj3.start();
		obj3.join();
		System.out.println("program ended");
	}
	
	catch(Exception e){

System.out.println("error");
	}		
	
	
	
	
	
	}
}