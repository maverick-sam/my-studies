class C{
public static void go(){
System.out.println("this is go methods");

}


}




class B implements Runnable{
	public void run(){
		try{
			for(int i=0;i<=5;i++)
			{   Thread.sleep(1000);
				System.out.println(i);
			}
		}
		catch(Exception e){
			System.out.println("error");
		}
	}
	public static void main(String args[])
	
	{
		B obj = new B();
		Thread t1 = new Thread(obj);
		t1.start();
		C.go();
	}
}

	