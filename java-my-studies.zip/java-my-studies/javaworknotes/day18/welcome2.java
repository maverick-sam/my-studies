class B extends Thread{
	public void run(){

	for(int i =0;i<=5;i++)
	{
		System.out.println(i);
	}
a
	
	}
	public static void main(String args[])
	{
		B obj = new B();
		obj.start();
		
		B obj1 = new B();
		obj1.start();
		
		B obj2 = new B();
		obj2.start();
	}
}