class Test{
	synchronized void test_main(int x){
		for(int i=0;i<5;i++)
		{
			try{
				Thread.sleep(500);
				System.out.println(x+i);
		} catch(Exception e)
		{
			System.out.println(e);
		}
		}
	}
}
public class Wel{
	public static void main(String args[])
	{
		Test obj = new Test();
		Thread t1 =new Thread(){
			public void run(){
			obj.test_main(10);}
		};
		Thread t2 =new Thread(){
			public void run(){
			obj.test_main(20);}
		};
		
				t1.start();
				t2.start();
	}
}
				
				
				
				
				
				
				
				
				
				
				