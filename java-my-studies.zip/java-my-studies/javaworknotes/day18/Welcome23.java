class Test{
	 void test_main(int x){
	synchronized(this){
	          for(int i=0;i<5;i++)
		       {
			try{
				Thread.sleep(500);
				System.out.println(x+i);
		} catch(Exception e)
		{
			System.out.println(e);
		}
		}
	}
}}
class Threadclass1 extends Thread{
	Test obj;
	Threadclass1(Test obj){
	this.obj=obj;}
	public void run()
	{
	obj.test_main(10);
	}
}
class Threadclass2 extends Thread{
	Test obj;
	Threadclass2(Test obj){
	this.obj=obj;}
	public void run()
	{
	obj.test_main(20);
	}
}
class Welcome23{
	public static void main (String args[]){
		Test obj = new Test();
		Threadclass1 t1 = new Threadclass1(obj);
		Threadclass2 t2 = new Threadclass2(obj);
		t1.start();
		t2.start();
	}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		