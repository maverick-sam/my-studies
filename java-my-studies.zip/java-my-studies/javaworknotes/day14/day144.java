class Whatsapp
{
	private String username;
	private String password;
	public void setusername(String username)
	{
		this.username=username;
	}
	public void setpassword(String password)
	{
		this.password=password;
	}
	public String getusername(){
return this.username;
	}
public String getpassword(){
return this.password;
}
}
class Admin
{
public static void main (String args[])
{
String username="samvspblindciri";
String password="cirithewitcher1234";
Whatsapp obj = new Whatsapp();

obj.setusername(username);
obj.setpassword(password);


String username1=obj.getusername();
String  password1=obj.getpassword();
System.out.println(username1);

System.out.println(password1);
}
}

