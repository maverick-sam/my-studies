class Gmaillogin{
	private String username;
	private String password;
	
	public void setusername(String username)
	{
		this.username=username;
	}
	public void setpassword(String password)
	{
		this.password=password;
	}
	public String getusername()
	{
		return this.username;
	}
	public String getpassword()
	{
		return this.password;
	}
}
class Server{
	public static void main(String args[]){
	String username="sankar16104@gamil.com";
	String password="6383106300";
	Gmaillogin obj = new Gmaillogin();
	
	obj.setusername(username);  ///////////object create and insert 
	obj.setpassword(password);
	
	String username1 =obj.getusername();  /////////////value get in same object
	String password1 = obj.getpassword();
	
	
	System.out.println(username1);
	System.out.println(password1); ///value print
}
	
}
	
	
	