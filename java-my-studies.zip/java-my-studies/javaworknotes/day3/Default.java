public class Default
{
 
 public static void main(String args[])
 {
 int age;
 char gender;
 System.out.println("the age is :"+age);
 }}