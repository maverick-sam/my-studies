
public class Welcome
{
	public static int emp_no;
	private static float size;
	protected static  char gender;
	protected static boolean yes_no;
	public static void go()

	{
		emp_no =102;
	size =22.5f;
	yes_no =false;
	gender ='f';
	
		System.out.println("this is go method");
		System.out.println(emp_no);
	System.out.println(size);
	System.out.println(gender);
	System.out.println(yes_no);
	}

	public static void main(String args[]){
		emp_no =101;
	size =23.5f;
	yes_no =true;
	gender ='m';
	System.out.println("this is main method");
	System.out.println(emp_no);
	System.out.println(size);
	System.out.println(gender);
	System.out.println(yes_no);
	System.out.println();
	go();
		System.out.println("this is main method");
	System.out.println(emp_no);
	System.out.println(size);
	System.out.println(gender);
	System.out.println(yes_no);
	System.out.println();
	}
}