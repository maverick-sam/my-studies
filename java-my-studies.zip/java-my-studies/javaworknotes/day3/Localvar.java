public class Localvar
{

public static int age= 20;
public float size=20.78f;
public static void main(String args[])
{
	System.out.println(age);
	Localvar xyz = new Localvar();
	System.out.println("size is"+xyz.size);
}}
	