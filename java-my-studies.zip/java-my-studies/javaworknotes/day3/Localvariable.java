//// local variable doesn't access other methods only access into the methods
///// local variable in don't use access specifier and static



public class Localvariable
{
	public static int emp_no;
	private static float salary;
	protected static  char gender;
	protected static boolean yes_no;
	public static void go()

	{
		emp_no =102; /// local variable
	salary =22.5f;

	
				System.out.println("this is go method");
	System.out.println(emp_no);
	System.out.println(salary);
	}

	public static void main(String args[]){
		emp_no =101;
	salary =23.5f;             /// local variable
	yes_no =true;
	gender ='m';
	System.out.println("this is main method");
	System.out.println(emp_no);
	System.out.println(salary);
	System.out.println(gender);
	System.out.println(yes_no);
	System.out.println();
	go();
		System.out.println("employee no is "+emp_no);
	System.out.println("employee salary"+salary);

///local variable concatenate


	
	}
}


