//// local variable doesn't access other methods only access into the methods
///// local variable in don't use access specifier and static



public class Localvariable2
/*
this is a error because global variable doesn't have same name it's indicates error
int age = 20;
int age = 20;
*/
{
	public static int emp_no;
	private static float salary;
	protected static  char gender;
	protected static boolean yes_no;
	public static void go()

	{
		emp_no =102;    /// local variable but local variables have same name because that local variables only access into this class only
	salary =22.5f;

	
				System.out.println("this is go method");
	System.out.println(emp_no);
	System.out.println(salary);
	}

	public static void main(String args[]){
		emp_no =101;
	salary =23.5f;             /// local variable
	
	System.out.println("this is main method");
	System.out.println(emp_no);
	System.out.println(salary);
	go();
	
	
///local variable concatenate
	
	



	
	}
}


