public class Nonstatic
{
public static int age =20;  /////////static varriable
public int age2=21;/////////////non-static

public static void go(){///////static method
	System.out.println("this is go method");
		Nonstatic abc = new Nonstatic();////// another object create 
	abc.good();///////////calll
	m1();
	
}
public void good(){
c
}
public static void m1(){
	System.out.println("this is m1 method");
}
public static void main(String args[]){///////////main method  
	System.out.println("this is main method");
	System.out.println("this is age"+age);
	Nonstatic obj = new Nonstatic();/////////////////// create object
     go();
    obj.good();
	System.out.println(obj.age2);
    m1();
}}	 