



public class Localglobal2
{
	public static int age = 21;      ////glopal variable
  
 
 
 public static void main(String args[])
 {
 int age = 20;      ////local variable
 
 
    
 System.out.println("the age is :"+age);
  System.out.println("the eag is :"+Localglobal2.age);
     

 
 }}