/////// if you want use declared locall variables in methods reinitialze the variables and use inn methods



public class Localglopal
{
	public static int age2 = 21;      ////glopal variable
    public static char gender2='f';
 
 
 public static void main(String args[])
 {
 int age = 20;      ////local variable
 char gender='m';
 
    
 System.out.println("the age is :"+age);
  System.out.println("the gender is :"+gender);
     
 System.out.println("the age2 is :"+age2);
  System.out.println("the gender2 is :"+gender2);
 
 }}