/////// if you want use declared locall variables in methods reinitialze the variables and use inn methods



public class Default2
{
 
 public static void main(String args[])
 {
 int age;      /////-----> to local variables declared variable 
 char gender;
 
    age=20; ////// don't use datatype in reinitialize the value
    gender='f'; //////-----> reinitialize the local variable and use in methods 
 System.out.println("the age is :"+age);
  System.out.println("the gender is :"+gender);
 }}