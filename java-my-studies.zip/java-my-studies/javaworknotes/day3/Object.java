
public class Object
{

 public void go(){
	System.out.println("this is non static method");
 }
 
 public static void main(String args[])
 {
System.out.println("this is static method");


Object abc = new Object();
abc.go();

 
 }}