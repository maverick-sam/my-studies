
public class Object2
{

 public void go(){
	System.out.println("this is non static method");
 }
  public static  void good(){
	System.out.println("this is static method");
 }
 
 
 public static void main(String args[])
 {
System.out.println("this is main method");

good();
Object abc = new Object();
abc.go();

 
 }}