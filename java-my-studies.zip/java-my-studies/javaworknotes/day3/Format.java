// format printing
public class Format
{
	public static String emp_name = "shankar";
	public static int emp_no = 101;
	private static float salary = 23.50f;
	protected static  char gender = 'm';
	protected static boolean yes_no = true;
	


	public static void main(String args[]){
	
	System.out.printf("this is main method");
		System.out.printf("employee name is %s\n",emp_name);
	System.out.printf("employee number is %d\n",emp_no);
	System.out.printf("employee salary is %.3f\n",salary);
	System.out.printf( "employee gender is %c\n",gender);
	System.out.printf("employee is permanent or not %b\n",yes_no);
	
	
/// concatenate operator


		System.out.println("employee name is "+emp_name);
	System.out.println("employee number is \n"+emp_no);
	
//// why use concatenate
System.out.printf("employee name is %s\nemployee number is %d\nemployee salary is %f\n",emp_name,emp_no,salary);


	
	}
}