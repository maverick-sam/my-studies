
public class Localglobal3
{
	public static int age = 21;      ////glopal variable
  
 
 
 public static void main(String args[])
 {
 int age = 20;      ////local variable
 
  age = 22; ////////// reinitialize local
    Localglobal3.age=30;///////////reinitializeglopal
 System.out.println("the age is :"+age);
  System.out.println("the eag is :"+Localglobal3.age);
     

 
 }}