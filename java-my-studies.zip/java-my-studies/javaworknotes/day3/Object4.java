
public class Object4
{

 public static void go(){//////n-static
	System.out.println("this is static method");
 }
  public void  good(){/////n-static
	System.out.println("this is non static method");
 go();
 }
 
 
 public static void main(String args[]) /////static
 {
System.out.println("this is main method");

Object4 abc = new Object4();
abc.good();
//// non static to non static no need to required obj
 
 }}