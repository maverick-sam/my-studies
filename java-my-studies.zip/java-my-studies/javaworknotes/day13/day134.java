class Hi{
	public Hi()
	{ super();
		System.out.println("that game name is");
	}
	public Hi(String name)
	{ super();
		System.out.println("that game name is"+name );
	}
	public Hi(String name , float C)
	{ super();
		System.out.println("that game name is"+name+"version"+C);
	}
	public void go(){
		System.out.println("that go method is ");
	}
	public  static void good(){
		System.out.println("that is good method");
	}
	public static void main(String args[])
	{
		Hi obi= new Hi("mario", 12.50f);
		obi.go();
		good();
	}
}
	