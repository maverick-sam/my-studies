interface A
{
	public void go();
}
class B implements A
{

public void go(){
			System.out.println("this go a");
		}




}

 class C implements A{
	
		
		public void go(){
			System.out.println("this go b");
		}
}
	
	
	
	
class Customer{	
	
	public static void main (String args[])
	{	
		A obj1=new B();
		obj1.go();
		A obj2=new C();
		obj2.go();
		
}
}