class Welcome{

public Welcome(){////////////////// default constructor called when obj creation 
System.out.println(" default method using object");
}


public void go(){
	System.out.println(" this is go method");
}
public void good(){
	System.out.println("this is good method");
}













public static void main(String args[])
{
	System.out.println("hello world......");

Welcome obj = new Welcome();
obj.go();
obj.good();





}
}
	