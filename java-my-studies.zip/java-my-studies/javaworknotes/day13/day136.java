class A {
public A(){
super ();
System.out.println("this is class a ");
}
}
class Hi extends A{
	public Hi(){
	super();
	System.out.println("this is hi class");
	}
	public void go(){
	System.out.println("this is go ");
	}
	public static void main(String args[])
	{
		Hi obj=new Hi();
		obj.go();
	}
	}
		