 import java.io.*;
 import java.util.*;
 class Welcome{
	 public static void main(String args[]) throws FileNotFoundException,IOException{
		 FileWriter fobj = new FileWriter("F:\\javaworknotes\\day19\\day19\\myfile.txt");
		 System.out.println("enter your details");
		 Scanner sc = new Scanner(System.in);
		 String information = sc.nextLine();
		 fobj.write(information);
		 fobj.close();
		 System.out.println("success");
	 }
 }
	 