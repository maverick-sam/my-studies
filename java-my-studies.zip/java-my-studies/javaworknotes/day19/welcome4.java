import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
class Welcome{
	public static void main(String args[])
	throws FileNotFoundException,IOException{
		FileInputStream fobj = new FileInputStream("F:\\javaworknotes\\day19\\day19\\myfile.txt");
		int value =fobj.read();
		System.out.println((char)value);
		fobj.close();
		System.out.println("success");
	}
}