 import java.io.FileInputStream;
 import java.io.FileNotFoundException;
 import java.io.IOException;
 
 class Welcome{
	 public static void main(String args[]) throws FileNotFoundException,IOException{
		 FileInputStream fobj = new FileInputStream("F:\\javaworknotes\\day19\\day19\\myfile.txt");
		 int val=0;
		 int count=0;
		 while((val=fobj.read()) != -1){
		 char valc = (char)val;
		if(valc =='u' ||valc =='i' ||valc =='o' ||valc =='e' ||valc =='a' )
		{
		System.out.print(valc);
		count++;
		 }}
		 System.out.println(count);
		
		 fobj.close();
	 System.out.println("success");
	 }
 }