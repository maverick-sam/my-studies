import java.io.*;

class Welcome{
	public static void main(String args[]) throws FileNotFoundException,IOException{
		FileOutputStream fobj = new FileOutputStream("F:\\javaworknotes\\day19\\day19\\myfile.txt");
		fobj.write(89);
		fobj.close();
		System.out.println("success");
	}
}

		