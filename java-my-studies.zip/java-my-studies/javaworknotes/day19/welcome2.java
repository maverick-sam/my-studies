import java.io.*;
import java.util.*;

class Welcome {
	public static void main(String args[])  throws FileNotFoundException,IOException{
		FileOutputStream fobj = new FileOutputStream("F:\\javaworknotes\\day19\\day19\\myfile2.text");
		System.out.print("enter your details");
		Scanner sc = new Scanner(System.in);
		String information =sc.nextLine();
		byte[] val =information.getBytes();
		fobj.write(val);
		fobj.close();
		System.out.println("success");
	}
}

	