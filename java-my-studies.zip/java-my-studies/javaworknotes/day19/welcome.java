import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
class B {
	public static void main(String args[])
	{
	
try{

	FileOutputStream fobj = new FileOutputStream("F:\\javaworknotes\\day19\\day19\\myfile.txt");
		fobj.write(78);
		fobj.close();
		System.out.println("success");
}
catch(FileNotFoundException e){
	System.out.println(e);
}
catch(IOException e){
	System.out.println(e);
}
	}
}