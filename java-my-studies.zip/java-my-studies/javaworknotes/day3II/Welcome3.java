public class Welcome3{  //////object as a return type

public  static void good(Welcome3 xyz)
{
System.out.println("this is good ");
System.out.println("xyz hash code " +xyz);
}
public static void main(String args[])
{   System.out.println("this is main"); 
 Welcome3 obj = new Welcome3();
             obj.good(obj);
	System.out.println("obj hash code"+obj);
	
	
}
}
