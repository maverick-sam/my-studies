public class Return{
public static int c(){
   int age =100;
 System.out.println("the age is"+age);
return age;
 }
 public static void main(String args[])
 {

System.out.println("this is main"); 
 int x=c();
 System.out.println("this is x "+x);
}}