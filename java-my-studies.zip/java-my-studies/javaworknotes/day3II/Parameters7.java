public class Parameters7
{
public void go(){
System.out.println("this is go method");
}
public static void good(Parameters7 obj){
	System.out.println("this is good");
	System.out.println("obj ="+obj);
	obj.go();
}
public static void main(String args[])
{
	System.out.println("this is main");
Parameters7 xyz = new Parameters7();
System.out.println("xyz="+xyz);
good(xyz);
}
}