public class Parameters5{
public static void go(Parameters5 obj){ 

}
public static  void main(String args[])
{
System.out.println("this is main method ");
go(new Parameters5()); 
}
}  