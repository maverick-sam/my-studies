public class Parameters6{
public  void good(){ 
System.out.println("this is good method ");
}
public static void go(Parameters6 obj){ 
System.out.println("this is go method ");
obj.good();
}
public static  void main(String args[])
{
System.out.println("this is main method ");
go(new Parameters6()); 
}
}  