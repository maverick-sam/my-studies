public class Reusability {
public static int add(int a, int b){          //////int is return type
 int c = a + b;
return c;////////////c is a return statement
} 
public static void main(String args[])
{
System.out.println("this is main");
int d =add(100,200);///////meethod calling and reusability
System.out.println("this is d  add value "+d);
}
}
