public class Welcome{  //////object as a return type
public void go(){
System.out.println("this is go method");
}
public static Welcome good()
{
System.out.println("this is  welcome ");
return  new Welcome();
}
public static void main(String args[])
{
	System.out.println("this is main");
	Welcome xyz = good(); ////// method calling 
	System.out.println("xyz hashcode is"+xyz);
	xyz.go();
}
}
