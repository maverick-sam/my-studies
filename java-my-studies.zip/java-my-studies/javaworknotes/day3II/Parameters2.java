public class Parameters2{
public void go(int a, float b){ //////parameters like as a local variable
System.out.println(a);
System.out.println(b);
}
public static  void main(String args[])
{
System.out.println("this is main method ");
Parameters2 obj = new Parameters2();//////////// object declaration
obj.go(100,50.89f);/////   arguments value is int 100 ,50.89f float value
}
}   