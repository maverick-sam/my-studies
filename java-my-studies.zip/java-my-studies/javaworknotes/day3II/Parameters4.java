public class Parameters4{
public static void good(int a, float b){ //////parameters like as a local variable
System.out.println("this is go method ");
System.out.println(a);
System.out.println(b);
}public static void go(char a, boolean b){ //////parameters like as a local variable
System.out.println("this is go method ");
System.out.println(a);
System.out.println(b);
good(100,13.90f);
}
public static  void main(String args[])
{
	char x='a'; /////////// local variable to use argument value
	boolean y=true;
System.out.println("this is main method ");

go(x,y);/////   arguments value is char a  boolean true value
}
}   
