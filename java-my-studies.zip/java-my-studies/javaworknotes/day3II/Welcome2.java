public class Welcome2{  //////object as a return type
public void go(){
System.out.println("this is go method");
}
public  Welcome good()
{
System.out.println("this is good ");
return  new Welcome2();
}
public static void main(String args[])
{   System.out.println("this is main"); 
 Welcome2 obj = new Welcome2();

	System.out.println("this is main");
	Welcome2 xyz = good(); ////// method calling 
	System.out.println("xyz hashcode is"+xyz);
	xyz.go();
}
}
