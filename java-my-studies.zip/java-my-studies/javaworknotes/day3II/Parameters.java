public class Parameters{
public void go(int a){ //////parameters like as a local variable
System.out.println(a);
}
public static  void main(String args[])
{
System.out.println("this is main method ");
Parameters obj = new Parameters();//////////// object declaration
obj.go(100);/////   arguments value is 100 
}
} 