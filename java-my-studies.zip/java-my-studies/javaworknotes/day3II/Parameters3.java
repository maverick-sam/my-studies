public class Parameters3{
public void go(int a, float b){ //////parameters like as a local variable
System.out.println("this is go method ");
System.out.println(a);
System.out.println(b);
}
public static  void main(String args[])
{
	int x=90; /////////// local variable to use argument value
	float y=50.0f;
System.out.println("this is main method ");
Parameters3 obj = new Parameters3();//////////// object declaration
obj.go(x,y);/////   arguments value is int90  50.0f float value
}
}   