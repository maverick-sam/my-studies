public class Return2{
public static float size()////// float  return type 
{
float  age= 50.5f;
System.out.println("the float size"+age);
return age; //// this is a return statement
}
public  static void main (String args[])
{
System.out.println("the main");
float xyz =size(); ///calling the method////return the value //the value stores in xyz
System.out.println("this is zyz"+xyz);
}}	
	