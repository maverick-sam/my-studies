public class Return3{
public static float size()////// float  return type 
{

System.out.println("the float size");
return 12.05f; //// this is a return statement /// return variable or value 
}
public  static void main (String args[])
{
System.out.println("the main");

System.out.println("this is zyz"+size()); /// method calling 
}}	
	