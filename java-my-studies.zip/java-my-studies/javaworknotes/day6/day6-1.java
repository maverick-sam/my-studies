class Test{
public static void main(String args[])
{
	
for(int i=1;i<=5;i++)
	
{
for(int a=0;a<5;a++)
{
	
	
System.out.print(i+" ");

}

System.out.println();
}
}
} 