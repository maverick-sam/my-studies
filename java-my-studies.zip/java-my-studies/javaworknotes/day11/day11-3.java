/*
method overriding in java*/
class A
{
	public void go(){
		System.out.println("this is go method of class a");
}}
class B extends A
{
	public void go(){
		System.out.println("this is go method of class B");
	super.go();
	}
		
		public static void main(String args[])
		{
		System.out.println("this is main method");
		B obj=new B();
		obj.go();
		
		}
		
	}	