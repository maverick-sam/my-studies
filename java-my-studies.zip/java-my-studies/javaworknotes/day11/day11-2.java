/*

java method overloading program:

*/
class A {
	public   void add(int x ,int y)
	
	{
		int c = x+y;
		System.out.println("the c value is ="+c);
	}
	public   void add(float x, float y)
	
	{
		float c = x+y;
		System.out.println("the c value is ="+c);
	}
	public   void add(long x ,long y)
	
	{
		long c = x+y;
		System.out.println("the c value is ="+c);
	}
public   void add(A obj2)
	
	{
	obj2.add(799,273);	
	}	
	public static void main(String args[])
	{
		System.out.println("this is main");
		A obj = new A();
		obj.add(100,200);
		obj.add(12.45f,67.7f);
		obj.add(1234567887l,234567876543l);
		obj.add(new A());
		
		
	}
}
		
		
		
		