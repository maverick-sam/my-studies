interface Bank
{
	public void username();
	public void userid();
	public void useraccountno();
}
abstract class Bank2 implements Bank{
public void userid(){
	System.out.println("the user id is 234");
}
public void useraccountno(){
	System.out.println("the usename account no is 23456789");
	
	
	}


}

class Sbi extends Bank2{
	public void username(){
		System.out.println("the username is : sam");
	}
	public static void main(String args[])
	{
		Sbi obj = new Sbi();
		obj.username();
		obj.userid();
		obj.useraccountno();
		
	}
}