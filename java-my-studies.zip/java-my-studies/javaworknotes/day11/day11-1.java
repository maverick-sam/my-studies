interface Bank
{
	public static  String bankname="sbi state bank of india";
	public static  String ifsccode="8793872349xyzx";
	public abstract void withdrawl();
	public abstract void balance();
	public  abstract void enquiry();
}
class SBI implements Bank{
	
	public  void  withdrawl(){
		System.out.println("withdrawl");
	}
	public void balance()
	{
		System.out.println("balance");
	}
	public void enquiry(){
		System.out.println("enquiry");
	}
	public static void main (String args[])
	{
		SBI obj= new SBI();
		obj.withdrawl();
		obj.balance();
		obj.enquiry();
		System.out.println(Bank.bankname);
		System.out.println(Bank.ifsccode);
	}
}