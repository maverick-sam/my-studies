interface A {
public void go();
}
interface B{
	public void good();
}
abstract class C{
	public abstract void go1();
}
 abstract class D extends C{
	public  abstract void go2();
}
class E extends D implements A,B{
	public void go(){
		System.out.println("go");
	}
	public void good(){
		System.out.println("good");
	}
	public void go1(){
		System.out.println("go1");
	}
	public void go2(){
		System.out.println("go2");
	}
	public static void main(String args[])
	{
		E obj = new E();
		obj.go();
		obj.good();
		obj.go1();
		obj.go2();
	}
}