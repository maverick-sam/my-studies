final class Hi{

public void go(){
	System.out.println("this is go method Hi");
}
public  void good(){
	System.out.println("this is good method Hi");
}
}
class Hello extends Hi{
	public void go(){
	System.out.println("this is go method HELLO");
}
public  void good(){
	System.out.println("this is good method HELLO");
super.go();
super.good();
}
public static void main (String args[]){
System.out.println("this is main");
Hello obj = new Hello();
obj.good();
obj.go();
}
}
