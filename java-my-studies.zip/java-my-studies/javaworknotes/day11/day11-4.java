abstract  class A{
	public abstract void go();
}
class B extends A
{
	public  void go(){
		System.out.println("this is go method");
	}
	public static void main(String args[])
	{
		B obj=new B();
		obj.go();
	}
}