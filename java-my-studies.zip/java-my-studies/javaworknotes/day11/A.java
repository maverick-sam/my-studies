public class A

{

	public  String  name = "sam";
	public final String name2 = "vikram";

public static void main(String args[])
{
	System.out.println("this is main program");
	A obj=new A();
obj.name2="safad";

	System.out.println(obj.name);
	System.out.println(obj.name2);
	System.out.println(obj.name2);
	}
}
 