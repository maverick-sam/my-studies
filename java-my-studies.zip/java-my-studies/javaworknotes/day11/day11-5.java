interface B
{      int x =100;
	 public void go();
}
class A implements B
{
	public void go(){
		System.out.println("this is go method");
	}
public static void main(String args[])
{
	System.out.println("this is main method");
	A obj=new A();
	obj.go();
	
System.out.println(x);





}}
 