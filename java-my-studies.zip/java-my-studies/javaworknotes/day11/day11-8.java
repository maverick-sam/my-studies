interface  Bank{
	public void pinchange();
}
interface  Bank2 extends Bank{
	public void deposit();
}
class Sbi implements Bank2{
	public void pinchange(){
		System.out.println("pinchange");
	}
	public void deposit(){
		System.out.println("deposit");
	}
	public static void main (String args[])
	{
		Sbi obj=new Sbi();
		obj.deposit();
		obj.pinchange();
	}
}