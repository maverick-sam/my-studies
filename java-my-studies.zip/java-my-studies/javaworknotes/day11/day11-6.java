public class A

{

	public void String  name = "sam";
	public final String name2 = "vikram";

public static void main(String args[])
{
	System.out.println("this is main program");
	A obj=new A();

	System.out.println(obj.name);
	System.out.println(obj.name2);
	}
}
 