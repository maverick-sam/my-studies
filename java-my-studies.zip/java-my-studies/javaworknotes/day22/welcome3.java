import java.util.*;
class B
{
	public static void main(String args[])
	{
		LinkedHashSet  ls= new LinkedHashSet();
		ls.add("sam");
		ls.add("vik");
		ls.add(12);
		System.out.println(ls);
	

Iterator itr =ls.iterator();
while(itr.hasNext())
{
	System.out.println(itr.next());
}	
	for(Object all :ls)
	{
		
System.out.println(all);	
	
	}
	}
}