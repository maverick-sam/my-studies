import java.util.*;
class B{
	
	public static void main(String args[])
	{
		HashSet hs =new HashSet();
		hs.add("sam");
		hs.add("john");
		hs.add(12);
	hs.add("sam");
		
		System.out.println(hs);
	//hs.clear();
	//System.out.println(hs);
	HashSet obj =(HashSet)hs.clone();
	System.out.println(obj);
	System.out.println(hs.hashCode());
	
	
	}
}
	
	
		
		
		