import java.util.*;
class B{
	public static void main(String args[])
	{
		TreeSet ts= new TreeSet();
		ts.add("sam");
		ts.add("vsp");
		ts.add("vick");
		System.out.println(ts);
	}
}