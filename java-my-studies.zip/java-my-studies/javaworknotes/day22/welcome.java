import java.util.*;
class B{
	public static void main(String args[])
	{
		HashSet hs=new HashSet();
		hs.add("sam");
		hs.add("john");
		hs.add(123);
		hs.add('b');
		hs.add(12.5);
		System.out.println(hs);
	Iterator i=hs.iterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	
	}
	
	}
}