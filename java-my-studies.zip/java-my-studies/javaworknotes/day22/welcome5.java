import java.util.*;
class B{
	public static void main(String args[])
	{
		
		ArrayDeque dq = new ArrayDeque();
		dq.add("arjun");
		dq.add("sam");
		dq.add("sma");
		System.out.println(dq);
		
		
		
		}
	
	
	 
	
}

		