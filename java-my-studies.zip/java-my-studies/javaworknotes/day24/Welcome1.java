import java.sql.*;
import java.util.*;

public class Welcome1 {
	
	public static void main(String args[]) {
		
		try {
			//load driver
			System.out.println("step 1");
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("step 1");
			//get connection
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306//ciri?autoReconnect=true&useSSL=false","root","ciri");
			
			//prepared statement
			String query = "SELECT * FROM student;";
			Statement stmt = con.createStatement();
			
			//query execute.
			ResultSet myRes = stmt.executeQuery(query);
			
			while(myRes.next()) {
				System.out.println(myRes.getInt("rollno")+" "+myRes.getString("stuname"));
			}
			con.close();
		}
		catch(ClassNotFoundException e) {
			
		}
		catch(SQLException e) {
			
		}
	}
}

		