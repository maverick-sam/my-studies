import java.sql.*;


class Test {
	
	public static void main(String args[]) {
		
		try {
			// Load driver
			System.out.println("Step 1: Load driver");
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			// Get connection
			System.out.println("Step 2: Get connection");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ciri?autoReconnect=true&useSSL=false", "root", "ciri");
			
			// Prepared statement
			System.out.println("Step 3: Create statement");
			String query = "SELECT * FROM student;";
			Statement stmt = con.createStatement();
			
			// Execute query
			System.out.println("Step 4: Execute query");
			ResultSet myRes = stmt.executeQuery(query);
			
			// Process results
			System.out.println("Step 5: Process results");
			while (myRes.next()) {
				System.out.println(myRes.getInt("rollno") + " " + myRes.getString("stuname"));
			}
			
			// Close connection
			con.close();
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
		}
	}
}
