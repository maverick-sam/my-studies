import java.sql.*;

class Test {
    public static void main(String[] args) {
        // JDBC URL, username, and password of MySQL server
        String jdbcUrl = "jdbc:mysql://localhost:3306/ciri?autoReconnect=true&useSSL=false";
        String username = "root";
        String password = "ciri";

        // SQL query
        String query = "SELECT * FROM student";

        // Using try-with-resources to ensure resources are closed properly
        try (
            // Get connection
            Connection con = DriverManager.getConnection(jdbcUrl, username, password);
            // Create statement
            Statement stmt = con.createStatement();
            // Execute query
            ResultSet rs = stmt.executeQuery(query)
        ) {
            // Process the result set
            while (rs.next()) {
                System.out.println(rs.getInt("rollno") + " " + rs.getString("stuname"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
