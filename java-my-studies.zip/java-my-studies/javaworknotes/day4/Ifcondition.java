/*
java (if condition ) syntax
if(condition){
	
	logics
}
*/
public class Ifcondition{
	public static void main(String args[]){
	int age =19;
	if(age>18) {  /////////////  >  that symbol is operator
		System.out.println("you're eligiple for vote");
	}
}
}