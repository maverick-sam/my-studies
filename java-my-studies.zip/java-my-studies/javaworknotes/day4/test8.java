class Test{
public static void main(String args[]){
for(int a=1;a<=10;a++){	//////// initialization ; condition ;incrementation
if(a==6){
	continue;
}	/////////// this statement is restart the current loop 
System.out.println(a);
}
}
}

