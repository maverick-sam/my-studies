 public class Switch{
 public static void main(String args[])
 {
 int value = 2;
 switch(value)   ///// switch is a kkeyword(value ) is a switch value 
 {
 case 2:   ////////////  case is key word 2 is a case value
 System.out.println("this is case 2 value ");
 break; /////////// break statement is must because this is exit the statement 
              ///////////////if not use break the out put is this is case 2 ,this is case 4 value ,this is case 4 value 
 
case 4:
 System.out.println("this is case 4 value ");
 break;

case 3:
 System.out.println("this is case 4 value ");
 break; 
 }}}