class  Test{
public static void main(String args[])
{
int i=10;
do{
System.out.println(i); //// no condition check  first print the value ass 10  
i++;
}
while(i<=5);
}}
  