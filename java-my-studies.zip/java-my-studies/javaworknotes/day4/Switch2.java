 public class Switch2{
 public static void main(String args[])
 {
 char s_char = 'z';
 switch(s_char)   ///// switch is a kkeyword(value ) is a switch value 
 {
 case 'e':   ////////////  case is key word 'e' is a case value
 System.out.println("this is vowel e ");
 break; /////////// break statement is must because this is exit the statement 
             
 
case 'a':
 System.out.println("this is vowel a ");
 break;

case 'i':
 System.out.println("this is vowel i ");
 break; 
 default:
 System.out.println(s_char+"this is not vowel ");
 }}}