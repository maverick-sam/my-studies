
public class Ifelseandoperator{
	public static void main(String args[]){
	int age =66;
	if(age>18 && age<=90) {  //// && that operator i logical and operator
		System.out.println("you're eligiple for vote");
	
	}
	else{ ////// optiional block
	System.out.println("uou're not eligiple for vote");
	
	
	
	}
	
	
	}



}