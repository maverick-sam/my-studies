
public class Ifelseandoperator2{
	public static void main(String args[]){
	int age =111;
	if(age>1 && age<=18) {  
		System.out.println("you're not eligiple for vote");
	
	}
	else if(age>=18 && age<=50) {
	System.out.println("uou're  eligiple for vote");
	}
	
		else if(age>60 && age<=100) {
		System.out.println("uou're senior eligiple for vote");}
			else  {
			System.out.println("uou're super senior  eligiple for vote");}
	}



} 