
public class Ifelseandoperator3{
	public static void main(String args[]){
	char s_char ='e';
	if(s_char == 'a' || s_char=='e') {  
		System.out.println("this is vowels");
	
	}

			else  {
			System.out.println(s_char+"this is not vowels");}
	}



} 