class Test{///////while loop  method
public static void main(String args[])
{
	int i=1;/////////////////// initialize value ubdate ,2,3,4,5,6,7,8,9,
while(i <=10)////////////conditon/////////and check every one loop count
{
	//////////incremernt /decrement loop run
	System.out.printf("the number  is :%d\n",i);

i++;}
}
}