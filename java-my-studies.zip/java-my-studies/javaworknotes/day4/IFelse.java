/*
java (if....else....condition ) syntax
if(condition){
	
	logics
}
else{ --------------optional block
	logics
}
*/
public class Ifelse{
	public static void main(String args[]){
	int age =10;
	if(age>18) {  
		System.out.println("you're eligiple for vote");
	
	}
	else{ ////// optiional block
	System.out.println("uou're not eligiple for vote");
	
	
	
	}
	
	
	}



}