class Test{
public static void main(String args[]){
for(int a=1;a<=10;a++){	//////// initialization ; condition ;incrementation
if(a==6){
	break;  //// break statement is fully break to the loop
}
System.out.println(a);
}
}
}

