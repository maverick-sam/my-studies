// this is variable and method calling program
public class Variable2
{
	public static int emp_n0 = 10012;
	private static float size = 23.5f;
	protected static  char gender = 'f';
	public static void go()
	{
		System.out.println("this is go method");
			System.out.println(emp_n0);
	System.out.println(size);
	System.out.println(gender);
	}

	public static void main(String args[]){
	System.out.println("this is main method");
	System.out.println(emp_n0);
	System.out.println(size);
	System.out.println(gender);
	System.out.println();
	go();
	
	}
}