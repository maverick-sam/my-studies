/* how access specifer works default specifer*/

class Hello
{
public static void main(String args[])
{
System.out.println("helloworld");
System.out.println("hello.....");
}
}