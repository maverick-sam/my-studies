public class Variable
{
	public static int emp_n0 = 10012;
	private static float size = 23.5f;
	protected static  char gender = 'f';
	public static void main(String args[]){
	System.out.println("this is main method");
	System.out.println(emp_n0);
	System.out.println(size);
	System.out.println(gender);
	
	}
}