public class Variable3
{
	public static int emp_n0 ;
	private static float size;
	protected static  char gender;
	static boolean yes_no;
	public static void main(String args[]){
	System.out.println("this is main method");
	System.out.println(emp_n0);
	System.out.println(size);
	System.out.println(gender);
	System.out.println(yes_no);
	
	}
}