public class Methodcalling3
{
public static void go()
{
	System.out.println("this is go method");
	good();
}
public static void good()
{
	System.out.println("this is good method ");
	m1();
}
public static void main(String args[]){
System.out.println("this is main method");
go();
}
public static void m1()
{
System.out.println("this is m1 method");
}

}