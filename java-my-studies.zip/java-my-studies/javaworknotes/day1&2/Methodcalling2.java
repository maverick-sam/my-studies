public class Methodcalling2
{
public static void go()
{
	System.out.println("this is go method");
	good();
}
public static void good()
{
	System.out.println("this is good method ");
}
public static void main(String args[]){
System.out.println("this is main method");
go();
}

}