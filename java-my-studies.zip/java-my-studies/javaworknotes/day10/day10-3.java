abstract class Hi{
	public abstract void go();
		
	
	public abstract  void go1();
	
	
}
class Hello extends Hi{  

public  void go(){
		System.out.println("this is  go amethod");
	}
	public  void go1(){
		System.out.println("this is go1 methods");
	}
	public static void main (String args[])
	{
		Hello obj = new Hello();
		obj.go();
		obj.go1();
	}
}