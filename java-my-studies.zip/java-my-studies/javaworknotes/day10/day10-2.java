 class A{
	public void go(){
		System.out.println("this is mjvhvgo");
}}
	 class B extends A{
	public void go(){
	System.out.println("this is go");
	super.go();
	}
public static void main (String args[])
{
	System.out.println("this is main");
	B obj=new B();
	obj.go();
	

	}}