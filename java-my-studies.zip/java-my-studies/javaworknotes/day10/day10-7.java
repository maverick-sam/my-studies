/* functionties on whatsapp
chat
whatsapp 
video
add acount
status    a,b,c,d,

*/

abstract class A{
	public abstract void chat();
	public abstract void whatsapp();
	public abstract void video();
	public abstract void addacount();
	public  void status(){
		System.out.println("finally users seing whatsapp status");
	}
}
abstract class B extends A
{
public void chat(){
		System.out.println("finally users seing whatsapp chat");

}}

abstract class C extends B{
public void whatsapp(){
		System.out.println("finally users seing whatsapp ");

}}

abstract class D extends C{
public void video(){
		System.out.println("finally users seing whatsapp video");
		

}}

abstract class E extends D{
public void addacount(){
		System.out.println("finally users addacount whatsapp");
	
}
}
class Admin extends E{
	public static void main(String args[])
	{
		System.out.println("this is admin login");
		Admin obj=new Admin();
		obj.chat();
		obj.addacount();
		obj.video();
		obj.status();
		obj.whatsapp();
		
		
		
}}
	

