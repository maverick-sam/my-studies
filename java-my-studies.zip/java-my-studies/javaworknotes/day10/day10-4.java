abstract class Hi1{
	public abstract void go();
		
	
	public abstract  void go1();
	public void m1(){
		System.out.println("this is m1 ");
	}
	
}
abstract class Hi extends Hi1{
	public abstract void go3();
		
	
	public abstract  void go2();
	public void m2(){
		System.out.println("this is m2 ");
	}
	
}
class Hello extends Hi{  

public  void go(){
		System.out.println("this is  go amethod");
	}
	public  void go1(){
		System.out.println("this is go1 methods");
	}
	public  void go2(){
		System.out.println("this is  go2 amethod");
	}
	public  void go3(){
		System.out.println("this is go3 methods");
	}
	public static void main (String args[])
	{
		Hello obj = new Hello();
		obj.go();
		obj.go1();
		obj.go2();
		obj.go3();
		obj.m1();
		obj.m2();
		
		
		
	}
}