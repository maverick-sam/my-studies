abstract class Hello{
	public  void go(){
		System.out.println("this is hello go");       //////// defined method
	}
	 public abstract void go1();//////// declared methods
}

class Hi extends Hello{
	public void m1(){
		System.out.println("this is m1 method");
	}
	public void go1(){
		System.out.println("this is go1 method");
	}
	public static void main(String args[])
	{
		Hi obj=new Hi();
		obj.m1();
		obj.go();
		obj.go1();
	}
}