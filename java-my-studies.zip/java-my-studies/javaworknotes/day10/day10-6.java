abstract class Hi{
	public static void go(){
		System.out.println("this is go");
	}
	public static int  x=100;
	String name ="raj";
	
}
class Hello extends Hi{
	public static void main(String args[])
	{
		Hello obj =new Hello();
		obj.go();
		System.out.println("th in x values ="+x);
		System.out.println("th in x values ="+obj.name);
	}
}