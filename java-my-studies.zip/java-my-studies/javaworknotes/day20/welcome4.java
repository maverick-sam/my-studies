import java.util.ArrayList;
 
class Welcome{
	public static void main(String args[])
	{
		ArrayList arr=new ArrayList();
arr.add("sam");	
arr.add("john");
arr.add("wick");
arr.add("vicksam");
arr.add("mark");

System.out.println(arr);
arr.add(2,"maverick");
System.out.println(arr);
	arr.clear();
	
	System.out.println(arr);
	boolean s =arr.contains(arr);
	System.out.println(s);
	}
}