 import java.util.ArrayList;
 class B{
	 public static void main(String args[])
	 {
		 ArrayList fobj = new ArrayList();
		 fobj.add(30);
		 fobj.add("sam");
		 fobj.add('a');
		 fobj.add(3022323);
		 System.out.println(fobj);
	 }
 }