import java.util.ArrayList;
import java.util.Iterator; 
class Welcome{
	public static void main(String args[])
	{
		ArrayList <String>arr=new ArrayList<String>();
arr.add("sam");	
arr.add("john");
arr.add("wick");
arr.add("vicksam");
arr.add("mark");

System.out.println(arr);
Iterator val =arr.iterator();
while(val.hasNext())
{
	System.out.println(val.next());
}
	}
}

	