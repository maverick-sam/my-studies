import java.util.*;
import java.lang.*;
class B{
	public static void main (String args[])
	{
		ArrayList arr = new ArrayList();
		arr.add(12);
		arr.add('s');
		arr.add("sam");
		arr.add(1234567);
		Iterator it =arr.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
}}