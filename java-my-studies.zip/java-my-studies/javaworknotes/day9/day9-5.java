///this is not method overriding concept ,we can achive this situvation by super().,


class Hi{
	public void go(){
		System.out.println("this is hi go method");
	}
	public void good(){
		System.out.println("this is hi good method");
}}
class Hello extends Hi{    ////////// so program no need extents keyword
	public void go(){
		System.out.println("this is hello go method");
	}
	public void good(){
		System.out.println("this is hello good method");
	}
		
		public static void main (String args[])
		{
			System.out.println("this is main method");
			Hello obj = new Hello();
			obj.go();
			obj.good();
			Hi obj1 = new Hi(); ///////// but this is not a method overriding because exttends keyword is use do reduce object
			obj1.go();
			obj1.good();
		
		}
}