class A{
	public void go(){
		System.out.println("this is go");
	}
	private static void good(int x){
		System.out.println("this is good method");
		System.out.printf("this is good int x value = %d",x);
	}
	public static void main(String args[])
	{
		System.out.println("this is main");
		A obj =new A();
		obj.go();
		good(100);
}}
	
		