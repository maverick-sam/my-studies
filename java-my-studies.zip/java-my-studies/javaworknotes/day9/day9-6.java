


class Hi{
	 void go(){
		System.out.println("this is hi go method");
	}
	protected void good(){
		System.out.println("this is hi good method");
}}
class Hello extends Hi{    
	public void go(){
		System.out.println("this is hello go method");
		super.go();  
	}
	protected void good(){
		System.out.println("this is hello good method");
		super.good();
	}
		
		public static void main (String args[])
		{
			System.out.println("this is main method");
			Hello obj = new Hello();
			obj.go();
			obj.good();
			
		
		}
}