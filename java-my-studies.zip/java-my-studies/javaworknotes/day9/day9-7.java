class FacebookOLDversion{
public void chat(){
System.out.println("Facebookoldversion chat ");
}
public void videocall(){
System.out.println("Facebookoldversion videocall ");
}
}
class FacebookNEWversion extends FacebookOLDversion {
public void chat(){
System.out.println("FacebookNEWversion chat ");
super.chat();
}
public void videocall(){
System.out.println("FacebookNEWversion videocall ");
super.videocall();
}
public static void main(String args[])
{
FacebookNEWversion obj =new FacebookNEWversion();
obj.chat();
obj.videocall();



}
}
