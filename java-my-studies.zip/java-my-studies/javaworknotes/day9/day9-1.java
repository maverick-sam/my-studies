class A{
	public void go(int x){
		System.out.println("this is go method");
		System.out.printf("this is int x value = %d\n",x);
	}
	public void go(float y){
		System.out.println("this go another method");
		System.out.printf("this is go float value y = %. 2f\n",y);
	}
	public static void main (String args[])
	{
		System.out.println("this is main");
		A obj=new A();
		obj.go(100);
		obj.go(100.20f);
	}
}