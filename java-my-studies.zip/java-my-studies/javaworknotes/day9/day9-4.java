class A{
	public static void add(int a, int b){
		int c= a+b;
		System.out.printf("add value is =%d\n",c);
	}
	public static void add(float a, float b){
		float c= a+b;
		System.out.printf(" add float value value is =%f\n",c);
	}
	public static void add(long a, long b){
		long c= a+b;
		System.out.printf("add value is =%d\n",c);
	
	}
	public static void main(String args[]){
		System.out.println("this  is main");
		add(100,200);
		add(20.50f,34.40f);
		add(6287468327l,7647268472l);
	}
}