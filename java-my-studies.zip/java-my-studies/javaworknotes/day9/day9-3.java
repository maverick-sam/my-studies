class A{
	public void go(byte a){
		System.out.println("this is go method");
		System.out.printf("a=%d\n",a);
	}
	public void go(double y){
		System.out.println("this is go method");
		System.out.printf("y=%.2f\n",y);
	}
	public static void main (String args[])
	{
		System.out.println("this is main");
		A obj = new A();
		obj.go((byte)100);
		obj.go(100.20);
	}
}	 