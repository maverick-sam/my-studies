

 class Test
 {
 protected void go() {
System.out.println("this is go method");
 }
public static void main(String args[])
{
System.out.println("this is main");
Test obj = new Test();
obj.go();
 }}	