
package day8.test1;


public class A2{
 void go1()
	{
		System.out.println("this is go ");
	}
	
}
