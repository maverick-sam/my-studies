package day8.test2;

 public class B
 {
public void go1() {
System.out.println("this is go1 method");
 }
}	