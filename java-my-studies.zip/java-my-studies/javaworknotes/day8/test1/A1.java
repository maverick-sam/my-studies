
package day8.test1;


public class A1{
 void go()
	{
		System.out.println("this is go ");
	}
	public static void main(String args[])
	{
		System.out.println("this  is main");
		A1 obj =new A1();
		obj.go();
        A2 obj1 =new A2();
		obj1.go1();	
	}
}
