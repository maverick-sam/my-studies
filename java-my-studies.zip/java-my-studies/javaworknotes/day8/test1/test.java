package day8.test1;
import day8.test2.B;
class A extends B
 {
 protected void go() {
System.out.println("this is go method");
 }
public static void main(String args[])
{
System.out.println("this is main");
A obj = new A();
obj.go();

B obj1=new B();
obj1.go1();
 }}	