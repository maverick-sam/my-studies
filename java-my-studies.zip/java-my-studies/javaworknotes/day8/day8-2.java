class A {
	public int age=20;
public void a(){
	System.out.println("this is a ");
}
}
class B extends A{
public  char b='a';
public void good(){
	System.out.println("this is b ");
}
}
class C extends B{
public char c='s';
public void c(){
	System.out.println("this is c");
}
}

class D extends C{
public boolean married=true;
public  static void main(String args[]){
	
System.out.println("this is d");
D obj = new D();
System.out.println(obj.married);
obj.c();
System.out.println(obj.c);
obj.good();
System.out.println(obj.b);
obj.a();
System.out.println(obj.age);
}}