class A{
	public void  a(){
		System.out.println("this is a ");
	}
}
class B extends A{
	public void  b(){
		System.out.println("this is b ");
	}
}
class C extends A{
	public void  c(){
		System.out.println("this is c ");
	}
}
class D extends A{
	public void  d(){
		System.out.println("this is d ");
	}
}
class E extends B{
	public static void main(String args[]){
	System.out.println("this is e");
E obj = new E();
obj.b();
obj.a();

C obj1 = new C();
obj1.c();
obj1.a();


D obj2 = new D();
obj2.d();
obj2.a();		
}
}