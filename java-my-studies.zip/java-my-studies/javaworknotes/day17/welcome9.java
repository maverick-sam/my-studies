import java.util.Scanner;
class B
{
	public static void main(String args[])
	{
		try{
			int accountbalance =5000
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("don't ender zero ,because zero divide ans is zero");
		}
	finally{
		System.out.println("log out successfully");
	
	
	}}
}
 