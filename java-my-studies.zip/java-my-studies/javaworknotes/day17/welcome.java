class B{
	
	public static void main(String args[])
	{
		System.out.println("program started");
		int c =10/2;
		System.out.println("c value is "+c);
		System.out.println("program ended");
	}
}
	