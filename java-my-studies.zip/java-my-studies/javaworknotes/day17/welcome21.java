import java.util.*;

class B{
	public static void main(String args[])
	{
		try{
			
			//// arithemetic exception
			int c =10/2;
			System.out.println("the c calculation value is "+c);
			////null value index
			String name="sam";
			String name2="sam";
			boolean finalname =name.equals(name2);
			System.out.println("final name is "+finalname);
			////numberformatindex out of
			Scanner sc = new Scanner(System.in);
			String agestr=sc.next();
			int age=Integer.parseInt(agestr);
			System.out.println(age);
			////array index out
			char[] value={'a','e','a','v','r','t'};
			for(int i=0;i<value.length;i++)
			{
				System.out.println(value[i]);
				
			}
			////////String
			String sam="sammaverick";
			char character =sam.charAt(89);
			System.out.println(character);
		}
		catch(ArithmeticException e){
			System.out.println("don't divide zero");
		}
		catch(NullPointerException e){
			System.out.println("pls give value don't null value");
		}
		catch(NumberFormatException e){
			System.out.println("pls give number not string");
		}	
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("give correct length value");
		}
		catch(Exception e){
			System.out.println("pls give correcct string value");
		}
	}
}