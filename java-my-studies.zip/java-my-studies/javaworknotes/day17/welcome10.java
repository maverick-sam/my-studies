import java.util.*;

class B
{
	public static void main(String args[])
	{
		try{
			int balance=5000;
			System.out.println("enter the withdrawl amount no");
			Scanner sc = new Scanner(System.in);
			int withdrawl=sc  nextInt();
			
			if(withdrawl>5000)
			{
			catch(ArithmeticException e){
				System.out.println("invald amount");
		}}}
			finally{
				System.out.println("log out successfully");
			}
	}
}