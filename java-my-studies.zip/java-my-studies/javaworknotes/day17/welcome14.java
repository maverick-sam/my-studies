import java.util.*;
class B{
	public static void main (String args[])
	{
		System.out.println("enter your age:");
		Scanner sc = new Scanner(System.in);
		String agestr= sc.next();/////sc.next();////////////is used to print first string
		int age =Integer.parseInt(agestr);
		System.out.println(age);
	}
}