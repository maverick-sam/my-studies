import java.util.Scanner;


class B 
{
	public static void main (String args[])
	
	{
		System.out.println(" your name is:");
		Scanner sc = new Scanner(System.in);
		String name=sc.next();
		System.out.println("your name is "+name);
		char[] name2=name.toCharArray();/////sam
		int count=0;
		for(int i=0;i<name2.length;i++)
		{
			if(name2[i]=='a' ||  name2[i]=='e')
			{
				count++;
			}
		}
	
	System.out.println("vowels count value "+count);
	 
	
	
	}
}
	
		
		
		
		
		
		
		
		
		


