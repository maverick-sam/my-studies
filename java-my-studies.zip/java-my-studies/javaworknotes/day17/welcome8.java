import java.util.Arrays;
class B{
	public static void main(String args[])
	{
		char[] name={'s','a','m','m','a','v','r','i','c','k'};
	Arrays.sort(name);
		System.out.println(name);
	}
}