class B{
public static void main(String args[])
{
	try{
		char[] value = new char[5];
		value[0]='a';
		value[1]='a';
		value[2]='a';
		value[3]='a';
		value[4]='a';
		value[5]='a';/////exception occure
		for(int i=0;i<value.length;i++)
		{
			System.out.println(value[i]);
		}
	}
	catch(ArrayIndexOutOfBoundsException e){
		System.out.println("pls give valid length value");
		System.out.println(e);
	}
}
}
		
		
		
		
		
		
		