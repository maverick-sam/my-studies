import java.util.*;
class B{
	public static void main(String args[])
	{
		
		String name =null;
		String name2="sam";
		boolean compare=name.equals(name2);
		System.out.println(compare);
	}
}
		
		
		
		
		
		
		
		