import java.util.Scanner;

class B{
	public static void main (String args[])
	{
		System.out.println("enter your age:");
		Scanner sc = new Scanner(System.in);
		int age = sc.nextInt();
		if(age>18 && age<120)
		{
			System.out.println("your're eligiple for vote");
		}
		else
		{
			System.out.println("you're not eligiple for vote");
		}
	}
}