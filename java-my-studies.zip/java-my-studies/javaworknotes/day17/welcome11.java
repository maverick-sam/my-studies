import java.util.*;
class B{
	public static void main (String args[])
	{
		try{
			System.out.println("atm process start");
			System.out.println("enter your amount");
			int balance=5000;
			Scanner sc = new Scanner(System.in);
			int wd = sc.nextInt();
		
		if(wd>balance)
			throw new ArithmeticException ();
		else
		System.out.println("transacation successfully processed");
		}
	catch(ArithmeticException e)
	{
		System.out.println("insufficient balance");
	}
	finally{
		System.out.println("end process");
	}
	}
}