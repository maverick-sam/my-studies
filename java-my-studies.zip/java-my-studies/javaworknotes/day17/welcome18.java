class B{
	public static void main(String args[])
	{
		try{
		int[] value={1,2,3,4,5,6,7};
		for(int i =0;i<=value.length;i++)
		{
			System.out.println(value[i]);
		}
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println("pls give valid index value");
	
	
	}
	
	}
}