class B
{
	public static void main(String args[])
	{
		try{
			String name="sammaverick";
			char name2=name.charAt(10);
			System.out.println(name2);
		}
		catch(StringIndexOutOfBoundsException e)
		{
			System.out.println("please give valid index value");
		}
	}
}
