/////null pointer excepion 


import java.util.*;
class B{
	public static void main(String args[])
	{
		try{
			System.out.println("start program");
		  String name ="maverick";
		String name2="sam";
		boolean compare=name.equals(name2);
		System.out.println(compare);
		System.out.println("program ended");
		
		
		
		}
		catch(NullPointerException e)
		{
			System.out.println("object shouldnt be a null value");
		}
	}
}
		
		
		
		
		
		
		
		