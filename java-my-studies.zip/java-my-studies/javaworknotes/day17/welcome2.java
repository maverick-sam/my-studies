class B{
	public static void main(String args[])
	{
		try{///////exception handling keywork
			System.out.println("program started");
			int c = 10/0;
			System.out.println("c values is="+c);
			System.out.println("program ended");
			
		}
		catch(ArithmeticException e){
			System.out.println("we can't divide by zero ,so please dont divide zero");
		}
	}
}
			