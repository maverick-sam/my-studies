import java.util.Scanner;

class B{
	public static void main (String args[])
	{
		System.out.println("enter your message");
		Scanner sc = new Scanner(System.in);
		String msg=sc.nextLine();
		System.out.println(msg);
	}
}