class B{
	public static void main(String args[])
	{
		int[] value={1,2,3,4,5,6,7};
		for(int i =0;i<=value.length;i++)
		{
			System.out.println(value[i]);
		}
	}
}