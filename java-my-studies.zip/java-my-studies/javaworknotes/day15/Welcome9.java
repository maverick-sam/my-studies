class B 
{
	public static void main(String args[])
	{
		StringBuilder name = new StringBuilder("sam captain maverick");
		System.out.println(name);
		char val = name.charAt(2);
		System.out.println(val);
		
		
		String val2 = name.substring(4,11);
		System.out.println(val2);
	
	
	
	
	
	
	
	
	}
}