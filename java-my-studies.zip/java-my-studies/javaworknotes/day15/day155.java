class Welcome{
	public static void main (String args[])
	{
		String name="hsankars";
		System.out.println(name);
	
		System.out.println(name.indexOf('s',2));
	}
}