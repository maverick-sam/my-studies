class A {
	public static void main(String args[])
	{
		String obj = new String("hello world");
		StringBuilder name = new StringBuilder(obj);
System.out.println(name);
}
}