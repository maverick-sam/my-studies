class Welcome
{
	public static void main(String args[])
	{
		char[] name={'s','a','m'};
		String name2 = new String(name);
		
		System.out.println(name2);
	}
}
