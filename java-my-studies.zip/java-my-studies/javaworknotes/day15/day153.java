class Welcome {
	public static void main(String args[])
	{
		String name="sam";
		String name2=new String("sam");
		boolean val = name.equals(name);
		System.out.println(val);
	}
}