class B
{
	public static void main(String args[])
	{
		
	StringBuffer sb1=new StringBuffer();
	System.out.println(sb1.capacity());
	
	


	
	sb1= new StringBuffer("s");
StringBuffer sb1 = new StringBuffer("	
	System.out.println(sb1);
System.out.println(sb1.capacity());

	
}
}