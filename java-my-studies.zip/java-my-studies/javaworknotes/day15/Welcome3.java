class B{
	public static void main(String args[])
	{
		StringBuilder name = new StringBuilder("hhjbjbjb");
		name.append("this is append method to store value in String builder this is mutable");
		System.out.println(name);
	}
}