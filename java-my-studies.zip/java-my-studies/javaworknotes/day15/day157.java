class Welcome
{
public static void main(String args[])
{
String name = "sam";
String name2 =  new String("sayygm");
System.out.println(name.hashCode());
System.out.println(name2.hashCode());
} 
}