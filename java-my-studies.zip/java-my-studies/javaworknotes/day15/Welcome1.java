class B{
	public static void main(String args[])
	{
		
		StringBuilder obj = new StringBuilder("sam")///////string builder object creation 
		System.out.println(obj);/////////sam string in stored in obj keyword so we call obj
	}
	}