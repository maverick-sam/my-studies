class Welcome{
public static void main(String args[])
{
String name="                      sam";
String val =name.trim('s','a');
System.out.println( val);
}
}