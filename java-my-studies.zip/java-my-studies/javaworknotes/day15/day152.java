class Welcome
{
	public static void main(String args[])
	{
		String name="shankar";
		String name2=new String("sam");
		System.out.println(name);
		System.out.println(name2);
		char val = name2.charAt(2);
		System.out.println(val);
	}
}
		