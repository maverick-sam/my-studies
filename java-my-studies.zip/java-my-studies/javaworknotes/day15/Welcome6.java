class B{
	public static void main(String args[])
	{
		String name = new String("sam");
	StringBuffer name2 =  new StringBuffer(name);
		System.out.println(name2);
	}
}