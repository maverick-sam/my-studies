class B {
	public static void main(String args[])
	{
		StringBuffer name = new StringBuffer("mav");
		int val =name.capacity();
		System.out.println(val);
		name.append("sam");
				System.out.println(name);
	}
}