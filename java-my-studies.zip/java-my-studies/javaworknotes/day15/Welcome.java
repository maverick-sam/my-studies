class Welcome {
	public static void main(String args[])
	{
		StringBuilder obj = new StringBuilder("hello world..");///////////object create for string buiilder
		System.out.println(obj);
	}
}