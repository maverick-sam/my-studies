class B {
public static void main(String args[])
{
StringBuilder obj = new StringBuilder(5);
System.out.println(obj.capacity());
obj.append("sam");
System.out.println(obj);
System.out.println(obj.capacity());

StringBuilder name2 = new StringBuilder("java program is must ");
int  name=name2.length();
System.out.println(name);




}}
