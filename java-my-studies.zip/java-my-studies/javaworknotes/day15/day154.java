class Welcome{
	public static void main(String args[])
	{
		String name="sam";
		System.out.println(name);
		String name2="sam";
		int val = name.hashCode();
		
		System.out.println(val);
	int val2 = name2.hashCode();
	System.out.println(val2);
	
	
	
	}
}