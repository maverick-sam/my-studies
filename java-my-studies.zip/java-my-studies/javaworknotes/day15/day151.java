class Welcome{
	public static void main(String args[])
	{
		String name="shankar";
		String name2=new String("vikram");
		System.out.println(name);
		System.out.println(name2);
	}
}
		