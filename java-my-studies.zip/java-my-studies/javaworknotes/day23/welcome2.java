import java.util.*;
class B{
public static void main(String args[])
{
	LinkedHashMap lhm = new LinkedHashMap();
	lhm.put("name","sam");
	lhm.put(1,23);
	lhm.put("work","it");
	lhm.put("work","google ceo");
	System.out.println(lhm);


Object values=lhm.get("name");
System.out.println(values);

Set<Map.Entry>set=lhm.entrySet();
Iterator itr=set.iterator();
while(itr.hasNext())
{
System.out.println(itr.next());


}	


}
}