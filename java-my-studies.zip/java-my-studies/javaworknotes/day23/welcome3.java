import java.util.*;
class B{
	public static void main(String args[])
	{
		TreeMap<Integer,String> tm = new TreeMap();
		tm.put("name","sam");
		tm.put("height","123");
		tm.put("work","IT");
		System.out.println(tm);
		
		NavigableMap nm=tm.descendingMap();
	
		
		Set<Map.Entry> s = nm.entrySet();
		Iterator itr=s.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}