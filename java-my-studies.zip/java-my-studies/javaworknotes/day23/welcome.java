import java.util.*;
class B{
	public static void main(String args[])
	{
		HashMap hm = new HashMap();
		
		hm.put(null,null);
		hm.put(2,"john");
		hm.put(3,"vick");
		hm.put(4,"arjun");
		
		Object hm1=hm.clone();
		System.out.println(hm1);
		System.out.println(hm);
Set<Map.Entry>s = hm.keySet();
Iterator itr=s.iterator();
while(itr.hasNext())
{
	System.out.println(itr.next());

}





	}
}
